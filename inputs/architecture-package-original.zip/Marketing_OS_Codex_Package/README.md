# Marketing OS — Codex product engineering handoff

This package contains a **complete specification**, the original owner-provided **Marketing Skills** archive, and developer-operating instructions. It is meant to be copied into your new Marketing OS codebase alongside a **separately checked-out** Postiz repository. The actual application is **not** contained in this handoff.

## Contents

- **`PRODUCT.md`** — the complete feature-by-feature, open-source reuse plan, technical architecture, API/data contracts, M0–M6 roadmap, acceptance tests, security, costs and scaling plan. **Read first.**
- **`ARCHITECTURE.md` + `diagrams/*.mmd`** — 13 editable Mermaid diagrams. `diagrams/INDEX.md` contains 8 SVG/PNG previews.
- **`INTEGRATION_FIRST_BUILD.md`** — backend-first, mock-vs-live rules, real integration evidence and strict no-UI-only gates.
- **`NO_FAKE_FEATURES_RELEASE_GATE.md` + `CODEX_FIRST_PROMPT.md`** — strict release acceptance and first Codex prompt.
- **`contracts/` + `templates/` + `scripts/`** — evidence contracts, config and state templates, fail-closed checker.
- **`CONFIGURE_AND_LAUNCH.md`** — what must already work in the build, what operator credentials/approvals are genuinely required, and self-serve readiness checks.
- **`AGENTS.md`** — Codex execution rules, product invariants, review gates and what NOT to invent.
- **`CODEX_START_HERE.md`** — copy/paste kickoff and file placement instructions.
- **`inventory/SKILLS_INVENTORY.csv`** — index of the 52 `SKILL.md` entries from the supplied archive with per-file content hashes.
- **`inventory/skills-archive.sha256`** — original archive checksum for provenance.
- **`inputs/marketingskills-main.zip`** — user's uploaded Marketing Skills archive, unchanged. Preserve its MIT license and upstream copyright notices. Audit helper scripts before use.

The ZIP **does not include Postiz**. Clone the real Postiz repository independently and pin its commit; Postiz's AGPL requirements must be reviewed for the intended commercial offering.

## Stack decisions

| Domain | Foundation |
|---|---|
| Runtime marketing skills | Deep Agents + actual imported 52 skills |
| Stateful orchestration | Deep Agents/LangGraph, plus Temporal for durable business jobs |
| Text | OpenAI model via adapter; Portkey optional for supported routing |
| Images | OpenAI GPT Images official SDK |
| Videos | Higgsfield official SDK + FFmpeg |
| Graphic editor | Fabric.js, plus custom editor UX |
| Website, guideline extraction | Crawl4AI + Docling |
| Brand Brain | PostgreSQL + pgvector + protected object storage |
| Observability and experiments | Langfuse; GrowthBook optional later |
| Social scheduling | Self-hosted Postiz **headlessly** |
| Product UI + SaaS | Our own frontend/backend, permissions and billing |

## Setup

1. Extract this package into the Marketing OS repository root, keeping the files and `inputs/` directory.
2. Clone Postiz **as a sibling repo** or a pinned submodule after license review (https://github.com/gitroomhq/postiz-app).
3. Give Codex access to both directories. Tell Codex: **“Read `AGENTS.md`, `PRODUCT.md`, `ARCHITECTURE.md`, and `INTEGRATION_FIRST_BUILD.md`. Perform M0 discovery, then implement real backend-to-UI slices with automated staging smoke tests. Do not stop at UI.”**
4. Have Codex implement mocked provider adapters and the first vertical slice before any live vendor calls. For later paid-provider integration tests, use separately provisioned development credentials and explicit limits.
5. Check each milestone's Definition of Done in `PRODUCT.md` **and** the integration evidence rules in `INTEGRATION_FIRST_BUILD.md` before moving on.
6. Validate an actual OpenAI image create/edit, Higgsfield video and tenant-safe Postiz test publish before declaring enabled features live-ready. An environment with no keys can only reach `ADAPTER_READY`.

## Product promise vs. existing code

This package defines how to **build** a Blaze.ai-like or better brand-specific marketing experience. No selected combination of repositories automatically provides it. M0 determines which Postiz connector flows are available without modifying upstream and whether there are licensing, integration or tenant safety blockers.

## Operational acceptance — the reason for this revised package

The user previously received frontend-only output from an implementation agent. This package explicitly prevents that. An integration is **not done** if the button is merely drawn, a mock responds, or a pretty dashboard displays fake analytics. The builder must implement SDK/API adapters, persistent jobs, tests, real-service smoke verification and secure setup flows. At the end the operator should configure cloud/domain, model keys, funding, OAuth developer apps and required approvals and **use** the finished application without manually writing missing integrations. External account approvals and commercial licensing are real-world prerequisites, not software bugs that a token budget can solve.

## Strongest start command

Give Codex [`CODEX_FIRST_PROMPT.md`](CODEX_FIRST_PROMPT.md). Require one genuinely working vertical slice and test output at a time. This package is a specification, not an already built platform.
