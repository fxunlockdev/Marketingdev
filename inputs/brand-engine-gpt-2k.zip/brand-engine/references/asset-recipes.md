# Brand Engine — Asset Recipes

Every recipe: (1) load required context, (2) generate, (3) run the Voice QA pass, (4) show
in chat + save to `brand/assets/<YYYY-MM-DD>-<slug>.md`. If `brand/strategy/` doesn't exist
yet, you may still generate — derive a quick persona/pain/angle inline from the knowledge
base, label it `[quick-derived — run /brand-engine strategy for the full map]`.

## Voice QA pass (mandatory, every asset, before showing the user)

1. Zero banned phrases from `voice.md` (scan literally; rewrite any hit)
2. Sentence length / pacing / emoji / caps rules followed
3. At least one verbatim customer phrase (or labeled hypothesis phrase) where the asset
   touches pain — copy should sound researched, not written
4. Pain–angle–hook layering intact (hook opens on the trigger, not the product)
5. No fabricated stats, reviews, or performance claims; compliance-sensitive categories
   (health, finance) get soft claims ("supports", "designed to") not cure/guarantee claims
6. Reads like the brand's GOOD examples, not its BAD ones

---

## `ad [topic|persona|brief-slug]` — Ad script

Context: config, voice, mechanism, customer-research, ad-scripts, hooks-data, strategy files.
If the user names a starred brief, script THAT brief. Otherwise pick the highest-priority
matching cell (or quick-derive).

Output:
- **Header**: persona × pain × awareness × format · runtime target
- **3 hook options** (0–3s), each on a different lever: pain-verbatim / pattern-interrupt /
  authority-claim (or curiosity, social proof — pick what fits the awareness stage)
- **Timestamped script** (two columns: VISUAL | VO/DIALOG) following the format's structure:
  hook → pain validation → mechanism entry → credibility anchor → objection handled →
  product reveal (timed to the awareness stage: later for cold, earlier for warm) →
  CTA matched to awareness (Most Aware gets the urgency mechanic; cold traffic gets a
  soft/identity close)
- **Production notes**: casting, setting, wardrobe, props, editing rhythm
- **Success metrics + kill criteria**

## `hooks [n]` — Hook batch (default 10)

Context: hooks-data (learn from logged winners first), pains quote bank, angles.
Output a table: # | Hook line | Persona | Awareness | Lever | Built from (quote/anchor).
Levers to spread across: verbatim pain · pattern interrupt · negation ("You're not lazy…") ·
specificity/number · authority reveal · curiosity gap · us-vs-category. Rules: ≤2 hooks per
lever per batch; every hook speakable in ≤3 seconds; no hook that requires the brand name to
make sense (cold hooks open on the customer, not the product).

## `post [platform] [topic]` — Social / marketing post

Platform defaults (override with user's stated prefs in config):
- **Instagram/Facebook**: hook first line (visible before "more"), 60–125 words, line breaks
  for rhythm, CTA, hashtags only if voice.md allows; + a one-line visual direction
- **TikTok caption**: ≤100 chars, curiosity or identity hook, minimal hashtags
- **LinkedIn**: hook line + white space, story or insight arc, no hashtag stuffing,
  founder-voice if config says founder-led
- **X/Twitter**: standalone punch ≤280 chars, or a labeled thread (hook tweet + 3–6 beats)
- **YouTube community / Threads**: conversational, question-close

Always: anchor on a persona pain or the mechanism — never generic category content. Offer a
3-post mini-series option when the topic has natural depth.

## `email [type]` — Email

Types: welcome · abandoned-cart · launch · winback · content/nurture.
Output: 3 subject lines (curiosity / pain / direct) + preview text · body in voice with
one idea per email · single CTA · PS line that re-hooks a secondary pain. Abandoned-cart and
winback must handle the REAL objection from the pain map, not just repeat the discount.

## `landing [section]` — Landing page copy

Sections: hero · mechanism · social-proof · comparison · FAQ · offer/close.
Hero = biggest pain promise in customer language + subhead carrying the mechanism + CTA.
Mechanism section follows mechanism.md's narrative (root cause → why alternatives fail →
how this works). Comparison section pulls from competitor-ads.md gaps. FAQ answers the
objections found in the pain clusters. Each section ships with a layout hint (one line).

## `captions [for-ad|for-video]` — Short captions/overlays

Text overlays for a supplied script or video concept: 5–8 beats, ≤6 words each, matching
the script's emotional arc; plus a thumbnail/cover text option.

## Freeform requests

Anything else ("write our bio", "name this bundle", "product description", "press blurb"):
map to the nearest recipe's discipline — persona-grounded, pain-anchored where relevant,
mechanism-backed, voice-checked — and save it like any asset.
