# Brand Engine — The 5-Pillar Strategy System

Run pillars in order for `strategy`; individually on request. Each pillar reads the
knowledge base + prior pillar outputs, and writes its result to `brand/strategy/`.
Show results in chat as clean tables AND save to disk.

---

## PILLAR 1 — Customer Personas → `strategy/personas.md`

### 1a. Generate (3–4 personas)

Sources: all `brand/` files. Hard rules:
- A persona is a **TYPE OF CUSTOMER**, defined by life situation + relationship to the
  problem. It must hold across all 5 awareness levels (Unaware → Most Aware). If it can't
  exist at every level, it's not a persona.
- Naming: `[Adjective + Adjective + Archetype]` (e.g., "Research-Rabbit-Hole First-Time Mom").
- NEVER define by awareness stage, mindset, funnel position ("Unaware Mom", "Skeptical
  Steven" = invalid). If a persona name contains an awareness word, regenerate it.
- Age/gender are context, not the persona.

Per persona output: name · life situation (what's happening day-to-day that opens them to
this product) · pain context · relationship to the problem (tried / fear / want) · 3–5
verbatim phrases WITH sources · why this brand over alternatives.

### 1b. Sub-persona split check

For each persona: does it contain multiple emotional wounds / failure modes / language
patterns / relationships to the problem? If yes → split into named sub-personas; validate
each still holds across all 5 awareness levels. If two personas share 50%+ of their pain
phrases → consolidate them. Each surviving persona needs a DISTINCT emotional wound,
distinct verbatim language, distinct failure mode.

Final output: persona/sub-persona list (typically 3–4 personas, up to 6–8 sub-personas) with
one-sentence definitions + **coverage state** each:
- **Scaling** — active ads targeting this persona 30+ days
- **Testing** — recent/low-volume creative testing
- **Not Running** — no creative currently targeting it
(Bootstrap mode or no ad account data: mark all "Not Running" and say why.)

---

## PILLAR 2 — Pain Points per Persona → `strategy/pains.md`

Pains come BEFORE angles. Pain = raw emotional trigger in the customer's own words.
Angle = narrative frame built on top. Weak ads start with angles pretending to be pains.

### 2a. Extract (3–5 raw pains per persona)

Rules:
- Verbatim language only, cited (source platform per quote). No marketing words
  ("obsessed", "game-changing", polished phrasing). If a pain sounds like a headline or
  positioning, it's one layer too high — re-extract the trigger underneath.
- Specific enough to picture ONE customer feeling it. "Wants better health" is not a pain;
  "avoids prenatals because she throws them up" is.
- Same pain language appearing 3+ times across sources → flag **HIGH-FREQUENCY ANCHOR**.

### 2b. Pressure test

Per pain: root pain or surface symptom? (surface → dig to the emotional root, e.g.
symptom quotes about nausea + skipping pills + fear → root = the guilt/fear loop of
"I physically can't take what my baby needs"). Cluster surface pains under roots. Rank by
cross-source verbatim match.

Output per persona: refined pain list (3–5) · **top pain to anchor on** · cluster map
(surface → root) · quote bank (8–12 strongest verbatim phrases).

---

## PILLAR 3 — Angles per Awareness Level → `strategy/angles.md`

Awareness levels describe **what the SCRIPT says at each stage**, not what the customer
thinks. Same persona + same pain → 5 different script jobs:

| Stage | The script's job | Example shape |
|---|---|---|
| Unaware | Connect symptom → problem they haven't framed yet | "Most women don't realize missing prenatals for weeks is common." |
| Problem Aware | Validate the pain, name the real culprit | "You're not lazy. Your formula is making you sick." |
| Solution Aware | Reframe a rival solution CATEGORY | "Gummies solve nausea but create nutrient gaps." |
| Product Aware | Position against a direct competitor | "Already taking Ritual but still nauseous?" |
| Most Aware | Trigger action NOW with a SPECIFIC urgency mechanic | "The methylated version sells out first every launch." |

### 3a. Generate

For each persona × top-pain combo: one single-line script direction per stage (≤5 total).
Note which pain anchors each. Most Aware MUST name the urgency mechanic (stock limit /
version launch / discount cliff / social-proof trigger / shipping deadline) — "buy now" is
not an angle. **Tolerate empty cells**: saturated categories (hair loss, debt, chronic pain,
weight loss…) often have no genuine Unaware population — leave the cell blank rather than
force-fill.

### 3b. Empty-cell warning check

If an Unaware angle actually reads as Problem/Solution Aware, surface it and diagnose:
- **(a) category gap** — no Unaware population exists → leave cell empty, annotate why (this
  is often the correct strategic answer)
- **(b) persona mis-defined** — the persona collapses two different personas → flag for
  re-cutting in Pillar 1

Sanity checks: if Unaware and Problem Aware angles could swap positions, the Unaware one is
mislabeled. If all 5 angles sound the same, regenerate — each level does a different job.
Angles are framing one layer ABOVE hooks (hooks come in the asset recipes).

Output: persona × awareness grid, every cell = valid angle or annotated blank.

---

## PILLAR 4 — Format & Structural Diversity → `strategy/formats.md`

Format is distribution strategy, not decoration. Meta's Andromeda compresses structurally
similar creatives into one entity bucket: 30 ads with different hooks but the same
narrator/setting/edit rhythm can count as ONE creative. Structural diversity > hook quantity.

### 4a. Format-to-angle matcher

Format library: podcast clip (host+expert, 30–60s) · authority figure in-studio
(pharmacist/doctor, 30–45s) · street interview with authority reveal (25–40s) · POV personal
story (creator first-person, 30–90s) · skit (skeptic + believer, 30–45s) · long-form
yapper/VSL (3–4 min) · educational walk-and-talk (supermarket/kitchen/bathroom) ·
spokesperson/debate · static comparison frames · native TikTok-style organic-mimicking.

Per valid angle: recommended format + one-line justification · alternative format for a
variant · why it beats default single-creator UGC · casting/setting notes (role, location,
energy). Match format to the ANGLE, not to the brand's habitual production style — a
biological villain-reveal at Problem Aware wants a podcast clip with an expert, not UGC.

### 4b. Andromeda structural diversity check

Identify each pair's structural signature: **narrator type** (creator / expert / actor /
multi-actor) × **scene** (studio / outdoor / home / pharmacy / street) × **edit rhythm**
(slow cut / fast cut / single-take / multi-scene). Cluster the pairs.

Risk score: **LOW** = 5+ distinct signatures · **MEDIUM** = 2–4 · **HIGH** = 1–2 signatures
dominate 80%+. For Medium/High: name which cells need structural breaks and specify the
break (different narrator, scene, and/or rhythm) so Andromeda reads them as separate
entity clusters.

Output: format–angle pairs table · signature cluster map · risk level · break
recommendations.

---

## PILLAR 5 — Strategy Map + Production Briefs → `strategy/strategy-map.md` + `strategy/briefs/`

### 5a. Synthesis + test queue

One table, Notion-ready: persona/sub-persona · pain anchor · awareness stage · angle ·
format · Andromeda signature · coverage state · priority. **Star the top 5–8 cells** by:
highest verbatim source match · structurally distinct format (new entity ID) · under-served
persona (Testing / Not Running) · fast-executable format.

Per starred cell, one hypothesis:
> "If we ship [angle] in [format] targeting [persona] at [awareness], we expect [specific
> outcome] because [mechanism]."

### 5b. Production briefs (one file per starred cell → `strategy/briefs/<slug>.md`)

Each brief must let a creator + editor produce the ad with zero follow-up strategy calls.
If a brief says "make it authentic," it's not a brief. Per brief:

- **Header**: persona × pain × awareness × format
- **Hook direction** (3-second opening direction only — not the full script)
- **Body structure** with timestamps: mechanism entry · credibility anchor timing ·
  product reveal timing · objection handled · close
- **Visual notes**: wardrobe, setting, lighting, props
- **Casting notes**: creator type, age range, energy
- **Runtime target**
- **Success metrics**: hook retention %, CPM target, CPA target (use brand's numbers if
  logged in the knowledge base; otherwise category-sensible defaults labeled as defaults)
- **Kill criteria**: e.g., hook retention <20% after $500 spend

Close with a **14-day sprint plan**: Week 1 concepts, Week 2 concepts, shoot batching by
format (all podcast clips one day, all street interviews another).

---

## Feed-forward map (why order matters)

Personas → pains are extracted per persona → angles are built per persona × top pain ×
awareness → formats are matched per angle and diversity-checked → the map prioritizes and
briefs operationalize. Empty-cell diagnoses feed back into Pillar 1 re-cuts. High-frequency
anchors and quote banks feed hook generation in the asset recipes. Performance logged via
`log` feeds coverage states and the next cycle's starred cells.
