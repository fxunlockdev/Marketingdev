# Brand Engine — Calendar Autopilot

Use this workflow when the user asks for an always-on agent, recurring creative production,
a content calendar, scheduled generation, or a loop. A chat session cannot remain in an
infinite background loop. Use the product's recurring automation or scheduler so each due
run wakes a fresh agent turn with the saved brand context.

## One-time setup

Require completed brand onboarding first. Then agree on:

- timezone and recurrence cadence
- channels and asset types
- weekly volume and platform dimensions
- content pillars, offers, personas, and exclusions
- variation rules and repetition limits
- approval mode: `generate-only` (default) or `publish-approved`
- output folder and notification preference

Create `brand/content-calendar.md` and `brand/production-ledger.md`. Treat the calendar as
authorization to generate only the listed assets. Do not infer permission to publish.

If a recurring automation tool is available, create or update one only after the user asks
to schedule it. The scheduled prompt must tell the agent to use this skill, read the saved
calendar, process due items, and update the ledger. Use the user's timezone. Prefer one daily
run that processes all due items over many fragile per-asset automations.

If no scheduler is available, explain that autonomous background execution is unavailable
in the current surface. Still create the calendar files and provide the exact recurring task
prompt for installation in a supported scheduler.

## Calendar format

Write `brand/content-calendar.md` with this structure:

```markdown
---
timezone: Asia/Kolkata
approval_mode: generate-only
catch_up: latest-only
max_assets_per_run: 4
status: active
---

| id | recurrence/date | channel | asset | pillar | audience | angle | format/size | CTA | status |
|---|---|---|---|---|---|---|---|---|---|
| weekly-education | Tue 10:00 | LinkedIn | static | Education | Persona A | Process | 4:5 | Read more | active |
```

Use stable IDs. For one-off rows, use an ISO date and time. For recurring rows, use a clear
weekday/cadence. Keep creative constraints concrete enough that a future run needs no new
prompt but flexible enough to avoid repetitive executions.

## Production ledger

Append one row per attempted asset to `brand/production-ledger.md`:

```markdown
| scheduled_for | calendar_id | started_at | result | asset_paths | concept_fingerprint | notes |
```

The `concept_fingerprint` is a short normalized signature such as
`persona|pain|angle|format|visual-device`. Before generating, scan recent successful rows.
Change at least two structural dimensions when a fingerprint is too similar to recent work.

## Scheduled run

On every scheduled wake-up:

1. Load the locked brand files, visual identity, calendar, and ledger.
2. Stop cleanly if calendar status is `paused`.
3. Determine what is due in the configured timezone. Skip items already completed for the
   same scheduled occurrence.
4. Apply `catch_up`: `none` skips missed work; `latest-only` creates only the newest missed
   occurrence; `all` processes backlog up to `max_assets_per_run`.
5. Produce each due item as a separate asset. Follow the copy and design recipes, use image
   generation where appropriate, inspect each output, and save final files under
   `brand/assets/<YYYY-MM-DD>/<calendar-id>/`.
6. Append success or failure to the ledger immediately after each item so retries are safe.
7. Continue past a single failed item when other due work can succeed. Never duplicate a
   successful occurrence during retry.
8. Return a compact run report: due, created, skipped, failed, saved paths, and next run.

## Approval and publishing

Default `generate-only` means save drafts locally and notify the user. Never post them.

`publish-approved` is valid only when the user explicitly requests publishing, names the
destination accounts/channels, approves the publishing cadence, and the necessary connector
is available. Even then:

- publish only calendar rows marked `approved`
- never create paid campaigns or spend budget from calendar permission alone
- log the external destination and returned post ID/URL
- on an ambiguous or failed publish, stop retrying after one safe check to avoid duplicates

## Control commands

- `autopilot pause` → set calendar status to `paused`; do not delete the calendar or ledger
- `autopilot resume` → set status to `active`
- `autopilot status` → summarize cadence, next due items, last run, failures, and output count
- `autopilot change ...` → edit only the named calendar fields and preserve stable IDs
- `run calendar now` → perform one immediate run without changing the recurring schedule

Never implement autonomy with an unbounded shell loop, `sleep`, or a process that must stay
open. Use durable scheduled wake-ups plus idempotent state files.
