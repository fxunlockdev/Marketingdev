# Brand Engine — One-Time Onboarding

Goal: build the brand knowledge base in `brand/` in one guided session. After this runs,
`brand/brand-config.md` exists and the skill NEVER asks setup questions again.

## Flow

### 1. Offer two paths

Ask the user (use AskUserQuestion if available):

> **How do you want to set up your brand?**
> - **Interview me (recommended)** — ~8 quick questions, 5 minutes
> - **I'll dump everything** — paste docs, ad transcripts, reviews, links; I'll extract the answers and only ask what's missing

If they choose the dump path: ingest what they paste, map it onto the file templates below,
then ask ONLY for genuinely missing required fields (brand name, product, tone). If they
provide file paths, Read those files.

### 2. The interview (five compact rounds, max 4 questions each)

**Round A — Brand basics**
1. Brand name + one-line description of what you sell (category + hero product)
2. Who buys it? Describe your best customer in your own words (life situation, not demographics)
3. Why do customers pick you over alternatives? Any unique mechanism, ingredient, method, or
   story? (If none: "no worries — I'll help develop one")
4. Top 2–3 direct competitors (names, and links to their ads if handy)

**Round B — Voice**
5. Pick 3 adjectives for your tone (offer options: warm / direct / playful / clinical /
   premium / rebellious / nerdy / calm / bold — plus free text). Any brands whose voice you admire?
6. Banned words and phrases — things you never want to see in your copy (offer common
   AI-slop defaults to ban: "game-changer", "unlock", "elevate", "obsessed", "say goodbye to",
   excessive emoji, em-dash overuse — let them add their own)
7. Formatting preferences: emoji yes/no, sentence length (punchy vs flowing), caps usage,
   hashtags yes/no

**Round C — Visual identity (optional but recommended — powers designed assets)**
- Brand colors (hex codes if known, or "pick for me" → propose a palette from the tone
  adjectives and confirm)
- Fonts: existing brand fonts, or a vibe (premium serif / clean grotesque / playful round /
  technical mono) → propose a pairing
- A style direction they're drawn to (show options: editorial · neo-brutalist · dark luxury ·
  light luxury · Swiss/minimal · bento · retro-futurist) — or "match my tone"
- Logo file path / visual references they admire (links, brands, screenshots)
If skipped entirely: on the FIRST design request later, propose an identity, confirm once,
save it — still a one-time ask.

**Round D — Evidence (all optional — say so explicitly)**
8. Paste anything real you have, in any messy format:
   - top-performing ad scripts or transcripts
   - hook lines + any performance numbers (impressions, CTR, hold rate, spend)
   - customer reviews, sales-call quotes, Reddit/TikTok/YouTube comments, support tickets
   - links or notes on competitor ads
   If they have nothing yet: enable **bootstrap mode** (see below) and reassure them the
   system compounds as real data arrives.

**Round E — Content calendar + autopilot (part of every setup)**

Set up the production system before locking the brand. Ask:

1. Which channels and asset types should the brand produce? Offer relevant options based on
   the business: Instagram statics/carousels/stories, LinkedIn, X, TikTok concepts, email,
   blog, landing-page experiments, ads, or another channel.
2. Desired cadence and timezone: assets per week, preferred days/times, and any launch dates.
3. Content mix: choose 3–5 recurring pillars and a rough distribution (education, product,
   proof, founder POV, objection handling, community, promotion). Infer a sensible draft from
   the earlier answers when the user says "pick for me."
4. Operation mode: `calendar-only`, `generate-only autopilot` (recommended), or
   `publish-approved`. Explain that automatic publishing requires explicit authorization and
   a connected destination; setup never grants permission to publish or spend.

Always create the calendar and ledger files, even when the user chooses `calendar-only` or
is not ready to activate scheduling. Use `status: draft` until cadence and content mix are
approved. Once approved, use `status: active` for generate-only production. Read
`references/automation.md` for the schema, scheduler setup, and safety rules.

### 3. Write the knowledge base

Create these files under `brand/` (create `brand/strategy/` and `brand/assets/` dirs too):

**`brand/brand-config.md`** — the lock file:
```markdown
---
brand: <name>
category: <category>
onboarded: <YYYY-MM-DD>
status: locked        # presence of this file = never re-ask onboarding questions
bootstrap_mode: true|false   # true if no real evidence was provided yet
autopilot_mode: calendar-only|generate-only|publish-approved
calendar_status: draft|active|paused
---
# <Brand> — Config
## Offer
<hero product, price point if given, promise>
## Best customer (founder's words)
<verbatim from onboarding>
## Differentiation
<why them over alternatives>
## Competitors
<list>
## Preferences
<anything else stated: platforms they post on, markets, compliance notes>
```

**`brand/voice.md`** — tone system:
```markdown
# Voice
## Tone
<3 adjectives + admired brands + what that means in practice, 3–5 bullets>
## Banned phrases (hard bans)
<list — always include the AI-slop defaults unless user objected>
## Sentence & pacing rules
<punchy/flowing, rhythm notes, caps, emoji, hashtags>
## Good vs bad
GOOD: <1–2 short examples in-voice — write them yourself from the tone answers, confirm with user>
BAD: <1–2 counter-examples showing what to avoid>
```

**`brand/mechanism.md`** — the narrative backbone:
If the user gave a mechanism, structure it: name → root-cause explanation → why alternatives
fail → proof points. If they didn't, DEVELOP one with them now: propose 2–3 candidate
mechanism framings from their differentiation answer, let them pick/edit one, then write it.
Mark it `[DRAFT MECHANISM — refine with customer evidence]` if invented today.

**`brand/visual-identity.md`** — design system (from Round C, or first design request):
```markdown
# Visual Identity
## Style direction
<one named direction + 2–3 sentences of what it means for this brand>
## Palette
<hex + role: surface / text / accent / semantic — with a light AND dark treatment>
## Typography
<display + body pairing, weights, where each is used>
## Layout & texture
<spacing rhythm, radius, shadow/depth policy, grain/texture yes-no>
## Do / Don't
<3 each, specific to this brand>
```

**`brand/customer-research.md`** — verbatim language bank:
Every quote gets a `— source:` tag (review / sales call / Reddit / TikTok / support / founder
memory). If bootstrap mode: seed with 8–12 `[HYPOTHESIS]` phrases you infer from the
category and best-customer description — clearly labeled, never presented as real quotes.

**`brand/competitor-ads.md`**:
What the user provided, plus a structural skeleton per competitor: positioning, likely
awareness coverage, mechanism narrative if visible, gaps we can attack. Label inferred parts.

**`brand/ad-scripts.md`** and **`brand/hooks-data.md`**:
Paste-in from the user, normalized (hooks table: hook line | metric(s) | source). If empty,
create the file with headers and a note: "Empty — append winners here; brand-engine reads
this before writing new ads."

**`brand/content-calendar.md`** and **`brand/production-ledger.md`**:
Create these during every onboarding using `references/automation.md`. Seed a rolling
four-week calendar from the agreed cadence and content mix. Assign stable row IDs and concrete
platform sizes. The ledger starts with its header and no fabricated production entries.

If the user selected active autopilot and a recurring automation tool is available, show the
final proposed cadence and scheduled task summary, obtain confirmation, then create the
recurring automation. Do not silently schedule a background task merely because onboarding
was completed. If scheduling is unavailable, leave the calendar ready and explain how it can
be activated later without redoing brand setup.

### 4. Confirm and lock

Show a compact summary (brand, tone in one line, mechanism in one line, evidence status,
channels, content cadence, calendar status, and autopilot mode).
Ask ONE final question: "Anything wrong before I lock it in?" Apply corrections, then
confirm: **"Brand and content system locked. I'll never ask these again — say `setup` or
`autopilot change` anytime to update something."**
Then immediately deliver whatever the user originally asked for, if anything.

## Bootstrap mode

Active when `bootstrap_mode: true`. Rules:
- Generate everything as normal, but inferred customer language carries `[HYPOTHESIS]`
- Every strategy output ends with a short "Feed me" note: the 1–2 real inputs that would most
  improve results (e.g., "paste 10 real reviews and I'll rebuild the pain map from them")
- When real evidence arrives via `log` or paste, update the file, and if the evidence is
  substantial (5+ real quotes), flip `bootstrap_mode: false` and offer to re-run Pillars 1–2.

## § Editing (post-lock changes)

Only an explicit user request ("setup", "change our tone", "add a competitor") re-opens
questions — and only for the named fields. Edit the specific file(s), update
`brand-config.md`'s changelog if identity-level, and note which downstream strategy files may
now be stale.
